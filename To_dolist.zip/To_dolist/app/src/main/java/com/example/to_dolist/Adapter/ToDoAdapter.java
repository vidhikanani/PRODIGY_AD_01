package com.example.to_dolist.Adapter;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.to_dolist.AddNewTask;
import com.example.to_dolist.Model.ToDoModel;
import com.example.to_dolist.R;
import com.example.to_dolist.Utils.DatabaseHandler;

import java.util.ArrayList;
import java.util.List;

public class ToDoAdapter extends RecyclerView.Adapter<ToDoAdapter.ViewHolder> {

    private List<ToDoModel> toDoList;
    private DatabaseHandler db;
    private Activity activity;

    // Constructor
    public ToDoAdapter(DatabaseHandler db, Activity activity) {
        this.db = db;
        this.activity = activity;
        this.toDoList = new ArrayList<>();  // Initialize the list
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the custom layout for each item
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.task_layout, parent, false);
        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        // Open the database
        db.openDatabase();

        // Get the item at the given position
        final ToDoModel item = toDoList.get(position);

        // Set the task text and checked state
        holder.task.setText(item.getTask());
        holder.task.setChecked(toBoolean(item.getStatus()));

        // Set a listener for checkbox changes
        holder.task.setOnCheckedChangeListener((buttonView, isChecked) -> {
            // Update the status in the database based on the checkbox state
            db.updateStatus(item.getId(), isChecked ? 1 : 0);
        });

        // Set a click listener for editing the task
        holder.itemView.setOnClickListener(view -> {
            Log.d("ToDoAdapter", "Clicked on task: " + item.getTask());
            Bundle bundle = new Bundle();
            bundle.putInt("id", item.getId());
            bundle.putString("task", item.getTask());
            AddNewTask dialog = AddNewTask.newInstance();
            dialog.setArguments(bundle);
            dialog.show(activity.getFragmentManager(), AddNewTask.TAG);
        });
    }

    @Override
    public int getItemCount() {
        return toDoList.size();
    }

    // Method to set the task list and refresh the RecyclerView
    public void setTasks(List<ToDoModel> toDoList) {
        this.toDoList = toDoList;
        notifyDataSetChanged();
    }

    // Convert an integer status to a boolean
    private boolean toBoolean(int n) {
        return n != 0;
    }

    // Method to delete a task
    public void deleteItem(int position) {
        ToDoModel item = toDoList.get(position);
        db.deleteTask(item.getId());
        toDoList.remove(position);
        notifyItemRemoved(position);
    }

    // ViewHolder class to hold the view for each task
    public static class ViewHolder extends RecyclerView.ViewHolder {
        CheckBox task;

        ViewHolder(View view) {
            super(view);
            task = view.findViewById(R.id.todoCheckBox);
        }
    }
}
